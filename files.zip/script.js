/* ────────────────────────────────────────────────────────────
   AURUM — Live Gold Price Engine
   Multi-tier fallback chain:
     1) gold-api.com        (free, no key, CORS-enabled)
     2) goldprice.org       (free, no key, secondary source)
     3) Simulated fallback  (only used if both live sources fail —
                              clearly labeled "Estimated (offline)")
   ──────────────────────────────────────────────────────────── */

const BASE_PRICE = 2034.50;
let currentPrice   = BASE_PRICE;
let previousPrice  = BASE_PRICE;
let liveChangePct  = null;      // % change reported by the live source, if any
let priceSource    = 'Connecting…';
let lastUpdated    = null;
let isLive         = false;

function fetchWithTimeout(url, timeout = 6000) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);
  return fetch(url, { signal: controller.signal, cache: 'no-store' })
    .then(res => {
      clearTimeout(id);
      if (!res.ok) throw new Error('HTTP ' + res.status);
      return res.json();
    })
    .finally(() => clearTimeout(id));
}

// Tier 1 — gold-api.com
async function fetchFromGoldApi() {
  const data = await fetchWithTimeout('https://api.gold-api.com/price/XAU');
  if (typeof data.price !== 'number') throw new Error('Unexpected payload');
  return { price: data.price, changePercent: null, source: 'Gold-API.com' };
}

// Tier 2 — goldprice.org
async function fetchFromGoldPriceOrg() {
  const data = await fetchWithTimeout('https://data-asg.goldprice.org/dbXRates/USD');
  const item = data && Array.isArray(data.items) ? data.items[0] : null;
  if (!item || typeof item.xauPrice !== 'number') throw new Error('Unexpected payload');
  return { price: item.xauPrice, changePercent: typeof item.pcXau === 'number' ? item.pcXau : null, source: 'GoldPrice.org' };
}

const PRICE_SOURCES = [fetchFromGoldApi, fetchFromGoldPriceOrg];

async function fetchLiveGoldPrice() {
  for (const fetcher of PRICE_SOURCES) {
    try {
      return await fetcher();
    } catch (err) {
      console.warn('[Aurum] live price source failed, trying next tier —', err.message);
    }
  }
  return null; // every tier failed
}

async function refreshGoldPrice() {
  previousPrice = currentPrice;
  const result = await fetchLiveGoldPrice();

  if (result) {
    currentPrice   = result.price;
    liveChangePct  = result.changePercent;
    priceSource    = result.source;
    isLive         = true;
  } else {
    // Tier 3 — graceful simulated fallback so the page still feels alive,
    // but clearly marked as an estimate rather than a live quote.
    const drift = (Math.random() - 0.5) * 2.5;
    currentPrice  = Math.max(1500, currentPrice + drift);
    liveChangePct = null;
    priceSource   = 'Estimated (offline)';
    isLive        = false;
  }

  lastUpdated = new Date();
  updatePriceUI();
  calcBuy();
  calcSell();
}

function timeAgoLabel(date) {
  if (!date) return 'just now';
  const secs = Math.floor((Date.now() - date.getTime()) / 1000);
  if (secs < 5)   return 'just now';
  if (secs < 60)  return secs + 's ago';
  const mins = Math.floor(secs / 60);
  return mins + 'm ago';
}

function updatePriceUI() {
  const buyEl   = document.getElementById('goldPriceBuy');
  const sellEl  = document.getElementById('goldPriceSell');
  const unitEl  = document.getElementById('priceUnitText');
  const sellUnitEl = document.getElementById('sellPriceUnitText');
  const dotEl   = document.getElementById('liveDot');
  const badgeEl = document.getElementById('priceChangeBadge');
  if (!buyEl) return;

  buyEl.textContent  = '$' + currentPrice.toFixed(2);
  sellEl.textContent = '$' + (currentPrice * 0.99).toFixed(2);

  if (unitEl) {
    unitEl.textContent = 'per troy ounce · Updated ' + timeAgoLabel(lastUpdated) + ' · via ' + priceSource;
  }
  if (sellUnitEl) {
    sellUnitEl.textContent = '99% of spot · via ' + priceSource;
  }
  if (dotEl) dotEl.classList.toggle('offline', !isLive);

  if (badgeEl) {
    const pct = liveChangePct != null
      ? liveChangePct
      : (previousPrice ? ((currentPrice - previousPrice) / previousPrice) * 100 : 0);
    const up = pct >= 0;
    badgeEl.textContent = (up ? '▲ +' : '▼ ') + pct.toFixed(2) + '%';
    badgeEl.className = up ? 'price-up' : 'price-down';
  }

  blinkPrice();
}

// Keep the "Updated Xs ago" text fresh even between fetches
setInterval(() => {
  const unitEl = document.getElementById('priceUnitText');
  if (unitEl && lastUpdated) {
    unitEl.textContent = 'per troy ounce · Updated ' + timeAgoLabel(lastUpdated) + ' · via ' + priceSource;
  }
}, 5000);

refreshGoldPrice();
setInterval(refreshGoldPrice, 30000); // gold-api.com refreshes its cache ~every 30s


function calcBuy() {
  const oz      = parseFloat(document.getElementById('buyProduct').value) || 1;
  const qty     = parseInt(document.getElementById('buyQty').value) || 1;
  const spot    = currentPrice * oz * qty;
  const premium = spot * 0.035;
  const total   = spot + premium + 12;

  document.getElementById('buySpot').textContent    = '$' + spot.toFixed(2);
  document.getElementById('buyPremium').textContent = '$' + premium.toFixed(2);
  document.getElementById('buyTotal').textContent   = '$' + total.toFixed(2);
}

calcBuy();


const KARAT_PURITY = {
  '24': 1,
  '22': 0.917,
  '18': 0.75,
  '14': 0.583,
  '10': 0.417
};

function calcSell() {
  const karat     = document.getElementById('sellType').value;
  const weight    = parseFloat(document.getElementById('sellWeight').value) || 0;
  const purity    = KARAT_PURITY[karat] || 1;
  const pureGrams = weight * purity;
  const pureOz    = pureGrams / 31.1035;
  const payout    = pureOz * currentPrice * 0.99;

  document.getElementById('sellPure').textContent  = pureGrams.toFixed(2) + ' g';
  document.getElementById('sellOz').textContent    = pureOz.toFixed(3) + ' oz';
  document.getElementById('sellTotal').textContent = '$' + payout.toFixed(2);
}

calcSell();


/* ── TICKER ── */
const tickerData = [
  { name: 'GOLD XAU/USD',    symbol: 'XAU', price: '$2,034.50', change: '+0.42%', up: true  },
  { name: 'SILVER XAG/USD',  symbol: 'XAG', price: '$23.84',    change: '+0.81%', up: true  },
  { name: 'PLATINUM',        symbol: 'XPT', price: '$1,012.20', change: '-0.15%', up: false },
  { name: 'PALLADIUM',       symbol: 'XPD', price: '$1,234.60', change: '+1.03%', up: true  },
  { name: 'COPPER',          symbol: 'HG',  price: '$3.847',    change: '-0.22%', up: false },
  { name: 'DXY (USD Index)', symbol: null,  price: '104.32',    change: '-0.18%', up: false },
  { name: 'GOLD FUTURES',    symbol: null,  price: '$2,041.80', change: '+0.38%', up: true  },
  { name: 'SILVER FUTURES',  symbol: null,  price: '$24.12',    change: '+0.95%', up: true  },
];

function buildTicker() {
  const inner  = document.getElementById('tickerInner');
  const doubled = [...tickerData, ...tickerData];

  inner.innerHTML = doubled.map(t => `
    <div class="ticker-item">
      <span class="ticker-name">${t.name}</span>
      <span class="ticker-price">${t.price}</span>
      <span class="ticker-change ${t.up ? 'up' : 'down'}">${t.change}</span>
      <span class="ticker-dot"></span>
    </div>
  `).join('');
}

buildTicker();

// Best-effort: pull live prices for the metals in the ticker too.
// Any symbol that fails to load simply keeps its last known demo value.
async function refreshTickerLive() {
  const jobs = tickerData
    .filter(t => t.symbol)
    .map(async t => {
      try {
        const data = await fetchWithTimeout('https://api.gold-api.com/price/' + t.symbol);
        if (typeof data.price === 'number') {
          t.price = '$' + data.price.toFixed(2);
        }
      } catch (e) { /* keep previous value */ }
    });
  await Promise.allSettled(jobs);
  buildTicker();
}

refreshTickerLive();
setInterval(refreshTickerLive, 60000);


/* ── PRODUCT ARTWORK (custom SVG, no stock photos / no copyright risk) ── */
function svgBar(labelBottom, big) {
  const w = big ? 240 : 220, h = big ? 160 : 150;
  const key = labelBottom.replace(/\s/g, '');
  return `
  <svg class="product-art" viewBox="0 0 ${w} ${h}" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="barTop-${key}" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#F5E9C4"/><stop offset="50%" stop-color="#C9A84C"/><stop offset="100%" stop-color="#8B6914"/>
      </linearGradient>
      <linearGradient id="barFront-${key}" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#E8C87A"/><stop offset="100%" stop-color="#5A420A"/>
      </linearGradient>
    </defs>
    <polygon points="${w*0.2},${h*0.16} ${w*0.8},${h*0.16} ${w*0.9},${h*0.3} ${w*0.1},${h*0.3}" fill="url(#barTop-${key})" stroke="#5A420A" stroke-width="1"/>
    <polygon points="${w*0.1},${h*0.3} ${w*0.9},${h*0.3} ${w*0.82},${h*0.78} ${w*0.18},${h*0.78}" fill="url(#barFront-${key})" stroke="#5A420A" stroke-width="1"/>
    <rect x="${w*0.28}" y="${h*0.4}" width="${w*0.44}" height="${h*0.28}" fill="none" stroke="rgba(10,10,10,0.35)" stroke-width="1"/>
    <text x="${w/2}" y="${h*0.53}" text-anchor="middle" font-family="'Playfair Display', serif" font-size="${big?16:14}" font-weight="700" fill="#1C1C1C">AURUM</text>
    <text x="${w/2}" y="${h*0.62}" text-anchor="middle" font-family="'Josefin Sans', sans-serif" font-size="8" letter-spacing="1" fill="#1C1C1C">999.9 FINE GOLD</text>
    <text x="${w/2}" y="${h*0.72}" text-anchor="middle" font-family="'Josefin Sans', sans-serif" font-size="7" letter-spacing="1" fill="rgba(28,28,28,0.65)">${labelBottom}</text>
  </svg>`;
}

function svgCoin(id, glyphSvg, labelTop, labelBottom) {
  return `
  <svg class="product-art" viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <radialGradient id="coinFace-${id}" cx="35%" cy="30%" r="75%">
        <stop offset="0%" stop-color="#F5E9C4"/><stop offset="55%" stop-color="#C9A84C"/><stop offset="100%" stop-color="#8B6914"/>
      </radialGradient>
    </defs>
    <circle cx="100" cy="100" r="88" fill="url(#coinFace-${id})" stroke="#5A420A" stroke-width="2"/>
    <circle cx="100" cy="100" r="88" fill="none" stroke="#5A420A" stroke-width="1" stroke-dasharray="2 2.6"/>
    <circle cx="100" cy="100" r="74" fill="none" stroke="rgba(28,28,28,0.4)" stroke-width="1"/>
    ${glyphSvg}
    <path id="topArc-${id}" d="M 28 104 A 72 72 0 0 1 172 104" fill="none"/>
    <text font-family="'Josefin Sans', sans-serif" font-size="9" letter-spacing="2" fill="#1C1C1C">
      <textPath href="#topArc-${id}" startOffset="50%" text-anchor="middle">${labelTop}</textPath>
    </text>
    <path id="botArc-${id}" d="M 172 100 A 72 72 0 0 1 28 100" fill="none"/>
    <text font-family="'Josefin Sans', sans-serif" font-size="8" letter-spacing="1.5" fill="rgba(28,28,28,0.65)">
      <textPath href="#botArc-${id}" startOffset="50%" text-anchor="middle">${labelBottom}</textPath>
    </text>
  </svg>`;
}

const GLYPHS = {
  star:   `<path d="M100 62 L112 90 L142 90 L118 108 L128 138 L100 120 L72 138 L82 108 L58 90 L88 90 Z" fill="#1C1C1C" opacity="0.55"/>`,
  leaf:   `<path d="M100 60 C106 72 118 75 126 68 C121 80 126 90 138 92 C126 96 124 108 132 116 C118 110 110 118 110 130 C110 118 100 116 95 123 C95 111 85 109 76 115 C84 106 79 94 67 92 C79 88 82 76 75 66 C87 73 96 68 100 60 Z" fill="#1C1C1C" opacity="0.55"/>`,
  shield: `<path d="M100 58 L132 70 L132 100 C132 120 118 136 100 142 C82 136 68 120 68 100 L68 70 Z" fill="none" stroke="#1C1C1C" stroke-width="3" opacity="0.6"/><line x1="100" y1="72" x2="100" y2="134" stroke="#1C1C1C" stroke-width="2" opacity="0.5"/><line x1="78" y1="96" x2="122" y2="96" stroke="#1C1C1C" stroke-width="2" opacity="0.5"/>`,
  wreath: `<path d="M74 132 C62 112 62 84 80 64" fill="none" stroke="#1C1C1C" stroke-width="2.5" opacity="0.55"/><path d="M126 132 C138 112 138 84 120 64" fill="none" stroke="#1C1C1C" stroke-width="2.5" opacity="0.55"/><circle cx="100" cy="102" r="20" fill="none" stroke="#1C1C1C" stroke-width="1.5" opacity="0.5"/><text x="100" y="109" text-anchor="middle" font-family="'Playfair Display', serif" font-size="16" font-weight="700" fill="#1C1C1C" opacity="0.7">Au</text>`
};

function productArt(p) {
  switch (p.id) {
    case 1: return svgBar('1 OZ BAR');
    case 2: return svgCoin('eagle',  GLYPHS.star,   'AMERICAN EAGLE', '1 OZ FINE GOLD');
    case 3: return svgCoin('maple',  GLYPHS.leaf,   'MAPLE LEAF',     '999.9 FINE GOLD');
    case 4: return svgBar('1 KILOGRAM', true);
    case 5: return svgCoin('brit',   GLYPHS.shield, 'BRITANNIA',      '999.9 FINE GOLD');
    case 6: return svgCoin('round',  GLYPHS.wreath, 'GOLD ROUND',     '999.9 FINE GOLD');
    default: return svgCoin('gold', GLYPHS.wreath, 'AURUM', '999.9 FINE GOLD');
  }
}


const products = [
  { id: 1, name: '1 oz Gold Bar',        spec: '99.99% Fine Gold · PAMP Suisse',   price: '$2,105',  badge: 'Best Seller', type: 'bar'   },
  { id: 2, name: 'American Gold Eagle',  spec: '1 oz · 22 Karat · US Mint',        price: '$2,165',  badge: 'Popular',     type: 'coin'  },
  { id: 3, name: 'Canadian Maple Leaf',  spec: '1 oz · 99.99% · Royal Mint',       price: '$2,110',  badge: null,          type: 'coin'  },
  { id: 4, name: 'Gold Kilo Bar',        spec: '32.15 oz · 99.99% Fine',           price: '$65,450', badge: 'Bulk Value',  type: 'bar'   },
  { id: 5, name: 'Gold Britannia',       spec: '1 oz · 99.99% · Royal Mint UK',    price: '$2,095',  badge: null,          type: 'coin'  },
  { id: 6, name: '1 oz Gold Round',      spec: '99.9% Fine · Generic Design',      price: '$2,068',  badge: 'Low Premium', type: 'round' },
];

function renderProducts(filter = 'all') {
  const grid     = document.getElementById('productsGrid');
  const filtered = filter === 'all'
    ? products
    : products.filter(p => p.type === filter);

  grid.innerHTML = filtered.map(p => `
    <div class="product-card" data-type="${p.type}">
      ${p.badge ? `<div class="product-badge">${p.badge}</div>` : ''}
      <div class="product-img">
        <div class="product-shine"></div>
        ${productArt(p)}
      </div>
      <div class="product-body">
        <div class="product-name">${p.name}</div>
        <div class="product-spec">${p.spec}</div>
        <div class="product-footer">
          <div class="product-price">${p.price}</div>
          <button class="product-buy" onclick="openModal('buy')">Buy Now</button>
        </div>
      </div>
    </div>
  `).join('');
}

renderProducts();

function filterProducts(type, btn) {
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  renderProducts(type);
}

/* ── MODAL ── */
function openModal(type) {
  const overlay = document.getElementById('modalOverlay');

  if (type === 'buy') {
    document.getElementById('modalTitle').textContent      = 'Confirm Purchase';
    document.getElementById('modalSub').textContent        = 'Review your order and select payment method';
    document.getElementById('modalPriceLabel').textContent = 'Total Amount';
    document.getElementById('modalPrice').textContent      = document.getElementById('buyTotal').textContent;
  } else {
    document.getElementById('modalTitle').textContent      = 'Confirm Sale';
    document.getElementById('modalSub').textContent        = 'You will receive payment within 24 hours of verification';
    document.getElementById('modalPriceLabel').textContent = 'You Receive';
    document.getElementById('modalPrice').textContent      = document.getElementById('sellTotal').textContent;
  }

  overlay.classList.add('open');
}

function closeModal(e) {
  if (e.target === document.getElementById('modalOverlay')) {
    document.getElementById('modalOverlay').classList.remove('open');
  }
}

function confirmOrder() {
  document.getElementById('modalOverlay').classList.remove('open');
  showToast('Order placed successfully! Confirmation sent to your email.');
}


function showToast(msg) {
  const toast = document.getElementById('toast');
  document.getElementById('toastText').textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 4000);
}


window.addEventListener('scroll', () => {
  document.getElementById('mainNav')
    .classList.toggle('scrolled', window.scrollY > 50);
});


function blinkPrice() {
  ['goldPriceBuy', 'goldPriceSell', 'buyTotal', 'sellTotal'].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.style.transition = 'color 0.15s';
      el.style.color = '#E8C87A';
      setTimeout(() => { el.style.color = ''; }, 300);
    }
  });
}
